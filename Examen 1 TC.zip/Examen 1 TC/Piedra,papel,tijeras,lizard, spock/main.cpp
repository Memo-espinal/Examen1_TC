#include <iostream>
#include <fstream>
#include <windows.h> 
#include <string>



using namespace std;

	string tijeras="";
	string roca="";
	string papel="";
	string lizard="";
	string spock="";

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int validar_jugadas(int jugada1, int jugada2){
	char FoV;
	switch(jugada1){
		case 1 :
				for(int i=0; i<=jugada2-1;i++){
					if(i==jugada2-1){
						FoV=tijeras[i];
					}
				}
			break;
		case 2: 
				for(int i=0; i<=jugada2-1;i++){
					if(i==jugada2-1){
						FoV=roca[i];
					}
				}
			break;
		case 3: 
				for(int i=0; i<=jugada2-1;i++){
					if(i==jugada2-1){
						FoV=papel[i];
					}
				}
			break;
		case 4: 
				for(int i=1; i<=jugada2-1;i++){
					if(i==jugada2-1){
						FoV=lizard[i];
					}
				}
			break;
		case 5: 
				for(int i=0; i<=jugada2-1;i++){
					if(i==jugada2-1){
						FoV=spock[i];
					}
				}
			break;
		
		default:
			break;
	}

	if(FoV=='F'&& jugada1==jugada2){
		cout<<"Empate"<<endl;
	}else if (FoV=='F'){
		cout<<"Jugador 2 gano"<<endl;
	}else{
		cout<<"Jugador 1 gano"<<endl;
	}
	return 0;	
}

void jugadas(){
	int jugada1,jugada2;
	cout<<"Jugador 1 porfavor elija su jugada!"<<endl;
	cout<<"1.- T= Tijeras\n2.- R= Roca\n3.- P= Papel\n4.- L= Lizard\n5.- S= Spock "<<endl;
	cin>> jugada1;
	while (jugada1>6 ||jugada1<1){
		//cin.clear();
		cout<<"Porfavor elija un numero valido"<< endl;
		cin>>jugada1;
	}
	//ahora jugador 2
	cout<<"Jugador 2 porfavor elija su jugada!"<<endl;
	cout<<"1.- T= Tijeras\n2.- R= Roca\n3.- P= Papel\n4.- L= Lizard\n5.- S= Spock "<<endl;
	cin>> jugada2;
	while (jugada2>6 ||jugada2<1){
		//cin.clear();
		cout<<"Porfavor elija un numero valido"<< endl;
		cin>>jugada2;
	}
	validar_jugadas(jugada1,jugada2);
}

int main(int argc, char** argv) {
	HANDLE  hConsole;
    hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	fstream my_file;
	my_file.open("tabla.txt", ios::in);
	if (!my_file) {
		cout << "No such file";
	}
	else {
		char ch;
		int cnt =1;
		int cnt_col = 0;
		
		hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
		while (cnt<=5) {
			//cout<<" ";
			my_file >> ch;
			
			
			
			
			if (my_file.eof())
				break;
			//switch case para agregar al string
			switch(cnt_col) {
     			case 0 :
         			//cout<<endl;
         			if(cnt==1){
         				cout<<"  ";	
					 }
         			break;
      			case 1 :
      				SetConsoleTextAttribute(hConsole, 13);
      				if(ch=='V'||ch=='F'){
      					tijeras+=ch;
					  }
					  break;
      			case 2 :
      				SetConsoleTextAttribute(hConsole, 12);
         			if(ch=='V'||ch=='F'){
      					roca+=ch;
					  }
         			break;
      			case 3 :
      				SetConsoleTextAttribute(hConsole, 14);
      				if(ch=='V'||ch=='F'){
      					papel+=ch;
					  }
         			
         			break;
      			case 4 :
      				SetConsoleTextAttribute(hConsole, 10);
      				if(ch=='V'||ch=='F'){
      					lizard+=ch;
					  }
         		
         			break;
         		case 5 :
         			SetConsoleTextAttribute(hConsole, 9);
      				if(ch=='V'||ch=='F'){
      					spock+=ch;
					  }
         			
         			break;
      			default :
      				break;
         			
   			}
			
			
			if(cnt==5){	
				cnt=0;
				cnt_col++;
			//    SetConsoleTextAttribute(hConsole, 11);

				cout<<" "<<ch<<endl;
				
			}else{
				//codigo para hacer cambiar de color
			//	SetConsoleTextAttribute(hConsole, 11);
				cout <<" "<< ch;
				cnt++;	
			}
			
		}
		

	}
	SetConsoleTextAttribute(hConsole,11);
	my_file.close();
	jugadas();
	return 0;
}
