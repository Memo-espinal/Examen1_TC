#ifndef E_H
#define E_H

class E
{
	public:
		char x;
		char y;
		int w;
		
		E();
		~E();
	protected:
};

#endif
