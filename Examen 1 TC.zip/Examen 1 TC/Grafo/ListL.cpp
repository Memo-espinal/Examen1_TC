#include "ListL.h"

ListL::ListL()
{
}

ListL::~ListL()
{
}
