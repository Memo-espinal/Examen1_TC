#ifndef LISTL_H
#define LISTL_H

class ListL
{
	public:
		ListL();
		~ListL();
	protected:
};

#endif
