#ifndef SET_V_H
#define SET_V_H

class set_v
{
	public:
		set_v();
		~set_v();
	protected:
};

#endif
