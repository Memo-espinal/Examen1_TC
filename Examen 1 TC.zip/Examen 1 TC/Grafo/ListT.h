#ifndef LISTT_H
#define LISTT_H
#include "E.h"

class ListT
{
	public:
		vector<E> v;
		
		ListT();
		~ListT();
	protected:
};

#endif
